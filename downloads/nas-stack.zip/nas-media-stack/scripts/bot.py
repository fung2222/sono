#!/usr/bin/env python3
"""
Telegram Bot for NAS media management.
Provides commands to control Bazarr, SubGen, qBittorrent, Jellyfin.
"""
import os
import json
import logging
import requests
from pathlib import Path
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s'
)
log = logging.getLogger('bot')

# Config from env
TELEGRAM_BOT_TOKEN = os.environ.get('TELEGRAM_BOT_TOKEN')
ALLOWED_CHAT_IDS = [int(x) for x in os.environ.get('ALLOWED_CHAT_IDS', '').split(',') if x]

QBITT_URL = os.environ.get('QBITT_URL')
QBITT_USER = os.environ.get('QBITT_USER')
QBITT_PASS = os.environ.get('QBITT_PASS')
JELLYFIN_URL = os.environ.get('JELLYFIN_URL')
JELLYFIN_API_KEY = os.environ.get('JELLYFIN_API_KEY')
MEDIA_PATH = os.environ.get('MEDIA_PATH', '/volume1/data/media')


def authorized(func):
    """Decorator: only allow whitelisted chat_ids."""
    async def wrapped(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if update.effective_chat.id not in ALLOWED_CHAT_IDS:
            await update.message.reply_text("⛔ Unauthorized. Your chat_id is not in whitelist.")
            log.warning(f"Unauthorized access from chat_id {update.effective_chat.id}")
            return
        return await func(update, context)
    return wrapped


@authorized
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Welcome message + command list."""
    msg = """
🤖 **NAS Media Bot** v1.0

**Commands:**
/status - SubGen status
/missing - List missing subtitles
/searchall - Trigger subtitle search
/qbitt - qBittorrent status
/jellyfin - Jellyfin status
/help - Show this help

**Setup verified by user.**
"""
    await update.message.reply_text(msg, parse_mode='Markdown')


@authorized
async def status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show SubGen status."""
    status_file = Path('/config/status.json')
    if status_file.exists():
        data = json.loads(status_file.read_text())
        msg = f"""
📊 **SubGen Status**

Last scan: {data.get('last_scan', 'N/A')}
Total videos: {data.get('total_videos', 0)}
Missing subs: {data.get('missing_count', 0)}
Downloaded: {data.get('downloaded_count', 0)}
"""
    else:
        msg = "⚠️ No scan data yet. Wait for first scan."
    await update.message.reply_text(msg, parse_mode='Markdown')


@authorized
async def missing(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """List videos with missing subtitles."""
    # Trigger subgen to generate list
    status_file = Path('/config/status.json')
    if status_file.exists():
        data = json.loads(status_file.read_text())
        msg = f"📋 {data.get('missing_count', 0)} videos have missing subtitles. Run /searchall to download."
    else:
        msg = "⚠️ No data yet."
    await update.message.reply_text(msg)


@authorized
async def searchall(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Trigger SubGen to search all missing subtitles."""
    await update.message.reply_text("🔍 Triggering SubGen search... (check logs)")
    # Trigger via Docker API or SSH
    try:
        import docker
        client = docker.from_env()
        container = client.containers.get('media-subgen')
        container.exec_run('python -c "import sys; sys.path.insert(0, \"/app\"); from subgen_runner import scan_media; scan_media()"')
        await update.message.reply_text("✅ Search triggered. Use /status in 1-2 min to see results.")
    except Exception as e:
        log.error(f"Trigger failed: {e}")
        await update.message.reply_text(f"❌ Failed: {e}")


@authorized
async def qbitt_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show qBittorrent status."""
    try:
        s = requests.Session()
        s.post(f'{QBITT_URL}/api/v2/auth/login', data={'username': QBITT_USER, 'password': QBITT_PASS})
        info = s.get(f'{QBITT_URL}/api/v2/torrents/info').json()
        downloading = sum(1 for t in info if t['state'] == 'downloading')
        completed = sum(1 for t in info if t['state'] == 'completed' or t['progress'] == 1)
        msg = f"""
📥 **qBittorrent Status**

Active downloads: {downloading}
Completed: {completed}
Total torrents: {len(info)}
"""
    except Exception as e:
        msg = f"❌ Failed: {e}"
    await update.message.reply_text(msg, parse_mode='Markdown')


@authorized
async def jellyfin_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show Jellyfin status."""
    try:
        headers = {'X-Emby-Token': JELLYFIN_API_KEY}
        info = requests.get(f'{JELLYFIN_URL}/System/Info', headers=headers).json()
        items = requests.get(f'{JELLYFIN_URL}/Items/Counts', headers=headers).json()
        msg = f"""
🎬 **Jellyfin Status**

Server: {info.get('ServerName', 'N/A')}
Version: {info.get('Version', 'N/A')}
Movies: {items.get('MovieCount', 0)}
Series: {items.get('SeriesCount', 0)}
Episodes: {items.get('EpisodeCount', 0)}
"""
    except Exception as e:
        msg = f"❌ Failed: {e}"
    await update.message.reply_text(msg, parse_mode='Markdown')


@authorized
async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await start(update, context)


def main():
    if not TELEGRAM_BOT_TOKEN:
        log.error("TELEGRAM_BOT_TOKEN not set")
        return

    app = Application.builder().token(TELEGRAM_BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("status", status))
    app.add_handler(CommandHandler("missing", missing))
    app.add_handler(CommandHandler("searchall", searchall))
    app.add_handler(CommandHandler("qbitt", qbitt_status))
    app.add_handler(CommandHandler("jellyfin", jellyfin_status))
    app.add_handler(CommandHandler("help", help_cmd))

    log.info("Bot started")
    app.run_polling()


if __name__ == '__main__':
    main()
