#!/usr/bin/env python3
"""
Post-Download Processor for NAS Media Stack.
Monitors BT folder, auto-downloads subtitles, renames, moves to library.

Supports OMDb API (TMDb alternative due to CloudFront blocking).
"""
import os
import re
import sys
import time
import json
import shutil
import logging
import requests
from pathlib import Path
from datetime import datetime
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler('/config/post_download.log'),
        logging.StreamHandler()
    ]
)
log = logging.getLogger('post_download')

# === Configuration (from env) ===
BT_FOLDER = os.environ.get('BT_FOLDER', '/volume1/BT')
MEDIA_FOLDER = os.environ.get('MEDIA_FOLDER', '/volume2/Media')
LANGUAGES = os.environ.get('LANGUAGES', 'zh-Hant,en,ja').split(',')
OMDB_API_KEY = os.environ.get('OMDB_API_KEY', '')

MOVIE_FOLDER = os.path.join(MEDIA_FOLDER, 'Movie')
TV_FOLDER = os.path.join(MEDIA_FOLDER, 'TV')
ANIME_FOLDER = os.path.join(MEDIA_FOLDER, 'Anime')

VIDEO_EXTS = {'.mkv', '.mp4', '.avi', '.mov', '.wmv', '.flv', '.webm'}
SUB_EXTS = {'.srt', '.vtt', '.ass', '.ssa'}

# Anime detection patterns
ANIME_PATTERNS = [
    r'\[SubsPlease\]', r'\[HorribleSubs\]', r'\[Erai-raws\]',
    r'\[AnimeRG\]', r'\[ASW\]', r'\[Judas\]', r'\[Commie\]',
    r'\[Kantai\]', r'\[FFF\]', r'\[Doki\]', r'\[Chihiro\]'
]

# Quality/Source strip patterns (for cleaner title extraction)
QUALITY_PATTERNS = [
    r'\.1080p\.?', r'\.720p\.?', r'\.2160p\.?', r'\.4K\.?',
    r'\.BluRay\.?', r'\.Blu-?Ray\.?', r'\.WEB[-.]?DL\.?',
    r'\.WEBRip\.?', r'\.HDTV\.?', r'\.WEB\.?',
    r'\.x264\.?', r'\.x265\.?', r'\.HEVC\.?', r'\.H\.264\.?', r'\.H\.265\.?',
    r'\.xvid\.?', r'\.DTS\.?', r'\.AC3\.?', r'\.AAC\.?',
    r'\.DDP\.?', r'\.Atmos\.?', r'\.TrueHD\.?',
    r'\.REMUX\.?', r'\.REMASTERED\.?', r'\.PROPER\.?',
    r'\.EXTENDED\.?', r'\.DIRECTORS?.CUT\.?',
    r'\.INTERNAL\.?', r'\.LIMITED\.?',
    r'\.MULTi\.?', r'\.DUAL\.?',
    r'[-_.]REPACK\.?', r'[-_.]REAL\.?',
    r'[-_.]COMPLETE\.?', r'[-_.]SEASON\.?'
]


def clean_filename(filename):
    """Extract clean title + year from filename."""
    stem = Path(filename).stem

    # Remove release group tags
    stem = re.sub(r'^\[.*?\]', '', stem)
    stem = re.sub(r'^\(.*?\)', '', stem)

    # Remove quality/source patterns
    for pat in QUALITY_PATTERNS:
        stem = re.sub(pat, ' ', stem, flags=re.IGNORECASE)

    # Try to extract title and year
    # Patterns: "Movie Title 2020" or "Movie Title (2020)"
    m = re.search(r'^(.+?)[\s._\-\(]+(\d{4})[\s._\-\)]', stem)
    if m:
        title = m.group(1).replace('.', ' ').replace('_', ' ').strip()
        year = m.group(2)
        title = ' '.join(w.capitalize() for w in title.split())
        title = re.sub(r'\s+', ' ', title)
        title = re.sub(r'[^\w\s-]', '', title)
        return title, year

    clean = re.sub(r'[\.\-_]', ' ', stem).strip()
    clean = re.sub(r'\s+', ' ', clean)
    return clean, ''


def search_omdb(title, year='', media_type='movie'):
    """Search OMDb for movie/show to get canonical info.

    Returns: dict with 'title', 'year', 'imdb_id', 'type' or None
    """
    if not OMDB_API_KEY:
        log.warning("OMDB_API_KEY not set, skipping metadata lookup")
        return None

    try:
        params = {
            'apikey': OMDB_API_KEY,
            't': title,
            'type': media_type,
            'r': 'json',
            'plot': 'short'
        }
        if year:
            params['y'] = year

        r = requests.get('http://www.omdbapi.com/', params=params, timeout=10)
        data = r.json()

        if data.get('Response') == 'True':
            return {
                'title': data.get('Title') or title,
                'year': data.get('Year', '').split('–')[0].strip() or year,
                'imdb_id': data.get('imdbID'),
                'type': data.get('Type', 'movie')
            }
        else:
            log.debug(f"OMDb: {data.get('Error')}")
    except Exception as e:
        log.error(f"OMDb search failed: {e}")
    return None


def is_anime(filename):
    """Detect anime by group/release tags."""
    for pat in ANIME_PATTERNS:
        if re.search(pat, filename):
            return True
    return False


def is_tv_show(filename):
    """Detect TV show by SxxExx pattern."""
    return bool(re.search(r'[Ss]\d{1,2}[Ee]\d{1,2}', filename))


def search_subtitle(video_path, lang, title_hint='', year_hint=''):
    """Search subtitle using subliminal (SubGen backend)."""
    try:
        from subliminal import Video as SubVideo, download_best_subtitles, save_subtitles
        sub = SubVideo.fromname(str(video_path))
        if title_hint:
            sub.title = title_hint
        if year_hint and year_hint.isdigit():
            sub.year = int(year_hint)

        subtitles = download_best_subtitles([sub], languages={lang})
        if subtitles.get(sub):
            save_subtitles(subtitles)
            return True
    except ImportError:
        log.warning("subliminal not available")
    except Exception as e:
        log.error(f"Subtitle search failed: {e}")
    return False


def determine_target_folder(filename, omdb_info):
    """Determine target folder based on OMDb info and filename."""
    if is_anime(filename):
        return ANIME_FOLDER

    if is_tv_show(filename):
        return TV_FOLDER

    if omdb_info and omdb_info.get('type') == 'series':
        return TV_FOLDER

    return MOVIE_FOLDER


def rename_movie_file(video_path, title, year):
    """Rename movie to TMM/Jellyfin standard format."""
    if year:
        new_name = f"{title} ({year}){video_path.suffix}"
    else:
        new_name = f"{title}{video_path.suffix}"

    new_path = video_path.parent / new_name

    if new_path == video_path:
        return video_path

    counter = 1
    while new_path.exists():
        if year:
            new_name = f"{title} ({year}) - {counter}{video_path.suffix}"
        else:
            new_name = f"{title} - {counter}{video_path.suffix}"
        new_path = video_path.parent / new_name
        counter += 1

    video_path.rename(new_path)
    log.info(f"Renamed: {Path(video_path).name} -> {new_name}")
    return new_path


def process_file(video_path):
    """Process single video file."""
    log.info(f"=== Processing: {video_path.name} ===")

    title, year = clean_filename(video_path.name)
    log.info(f"  Parsed: title='{title}' year='{year}'")

    # OMDb lookup
    omdb_info = None
    if OMDB_API_KEY:
        omdb_info = search_omdb(title, year)
        if omdb_info:
            log.info(f"  OMDb: {omdb_info['title']} ({omdb_info['year']}) [{omdb_info['type']}] [imdb={omdb_info.get('imdb_id')}]")
            title = omdb_info['title']
            year = omdb_info['year']
        else:
            log.info("  OMDb: no match, using filename")

    # Search subtitles for each language
    for lang in LANGUAGES:
        if not any(video_path.with_suffix(f'.{lang}{ext}').exists() for ext in SUB_EXTS):
            log.info(f"  Searching [{lang}] subtitle...")
            if search_subtitle(video_path, lang, title, year):
                log.info(f"  ✅ Found [{lang}] subtitle")
            else:
                log.info(f"  ⚠️ No [{lang}] subtitle found")

    # Categorize and rename
    target_folder = determine_target_folder(video_path.name, omdb_info)
    log.info(f"  Target folder: {target_folder}")

    if target_folder in (ANIME_FOLDER, TV_FOLDER):
        new_path = video_path  # Keep original filename
    else:
        new_path = rename_movie_file(video_path, title, year)

    # Move to target folder
    final_path = Path(target_folder) / new_path.name

    if final_path.exists() and final_path != new_path:
        log.warning(f"  Target already exists: {final_path}")
        counter = 1
        stem = new_path.stem
        suffix = new_path.suffix
        while final_path.exists():
            final_path = Path(target_folder) / f"{stem} - {counter}{suffix}"
            counter += 1

    if new_path != final_path:
        try:
            shutil.move(str(new_path), str(final_path))
            log.info(f"  ✅ Moved to: {final_path}")
        except Exception as e:
            log.error(f"  Failed to move: {e}")

    return final_path


class VideoHandler(FileSystemEventHandler):
    def on_created(self, event):
        if event.is_directory:
            return
        path = Path(event.src_path)
        ext = path.suffix.lower()
        if ext in VIDEO_EXTS:
            log.info(f"New video detected: {path.name}")
            self.wait_for_complete(path)

    def wait_for_complete(self, path, timeout=600):
        """Wait for qBittorrent to finish downloading."""
        last_size = -1
        stable_count = 0
        start = time.time()

        while time.time() - start < timeout:
            try:
                current_size = os.path.getsize(path)
                if current_size == last_size and current_size > 0:
                    stable_count += 1
                    if stable_count >= 6:
                        log.info(f"File stable: {path.name} ({current_size} bytes)")
                        self.process_with_retry(path)
                        return
                else:
                    stable_count = 0
                    last_size = current_size
            except OSError:
                pass
            time.sleep(5)
        log.warning(f"File not stable after {timeout}s, processing anyway")
        self.process_with_retry(path)

    def process_with_retry(self, path, retries=3):
        for i in range(retries):
            try:
                process_file(path)
                return
            except Exception as e:
                log.error(f"Process attempt {i+1} failed: {e}")
                if i < retries - 1:
                    time.sleep(30)


def main():
    if not os.path.exists(BT_FOLDER):
        log.error(f"BT folder {BT_FOLDER} does not exist")
        return

    log.info(f"=== Post-Download Processor Started ===")
    log.info(f"BT folder: {BT_FOLDER}")
    log.info(f"Media folder: {MEDIA_FOLDER}")
    log.info(f"Languages: {LANGUAGES}")
    log.info(f"OMDb API: {'configured' if OMDB_API_KEY else 'NOT configured'}")

    event_handler = VideoHandler()
    observer = Observer()
    observer.schedule(event_handler, BT_FOLDER, recursive=True)
    observer.start()

    log.info(f"Watching {BT_FOLDER} for new video files...")
    try:
        while True:
            time.sleep(60)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()


if __name__ == '__main__':
    main()
