#!/usr/bin/env python3
"""
SubGen-style subtitle downloader.
Scans media folder for video files, searches for missing subtitles, downloads.
"""
import os
import sys
import time
import json
import logging
import subprocess
from pathlib import Path
from datetime import datetime

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler('/config/subgen.log'),
        logging.StreamHandler()
    ]
)
log = logging.getLogger('subgen')

MEDIA_PATH = os.environ.get('MEDIA_PATH', '/volume1/data/media')
LANGUAGES = os.environ.get('LANGUAGES', 'zh-Hant,en,ja').split(',')
SCAN_INTERVAL = int(os.environ.get('SCAN_INTERVAL_HOURS', 6)) * 3600

VIDEO_EXTS = {'.mkv', '.mp4', '.avi', '.mov', '.wmv', '.flv', '.webm'}


def find_videos(root):
    """Recursively find all video files."""
    videos = []
    for path in Path(root).rglob('*'):
        if path.is_file() and path.suffix.lower() in VIDEO_EXTS:
            videos.append(path)
    return videos


def has_subtitle(video, lang):
    """Check if subtitle file exists for given language."""
    base = video.with_suffix('')
    patterns = [
        f"{base.name}.{lang}.srt",
        f"{base.name}.{lang}.vtt",
        f"{base.name}.{lang}.ass",
    ]
    return any(p.exists() for p in patterns)


def search_subtitle(video, lang):
    """Search subtitle for a video file. Returns URL or None."""
    # Use subliminal (Python lib) if available, else fallback to manual API
    try:
        from subliminal import Video as SubVideo, download_best_subtitles, save_subtitles
        sub = SubVideo.fromname(str(video))
        subtitles = download_best_subtitles([sub], languages={lang})
        if subtitles.get(sub):
            save_subtitles(subtitles)
            return True
    except ImportError:
        log.warning("subliminal not installed, using fallback")
    except Exception as e:
        log.error(f"Subtitle search failed for {video}: {e}")
    return False


def scan_media():
    """Main scan: find missing subtitles, download."""
    log.info(f"=== Scan started: {datetime.now().isoformat()} ===")
    log.info(f"Media path: {MEDIA_PATH}")
    log.info(f"Languages: {LANGUAGES}")

    if not os.path.exists(MEDIA_PATH):
        log.error(f"Media path {MEDIA_PATH} does not exist")
        return

    videos = find_videos(MEDIA_PATH)
    log.info(f"Found {len(videos)} video files")

    missing_count = 0
    downloaded_count = 0

    for video in videos:
        for lang in LANGUAGES:
            if not has_subtitle(video, lang):
                missing_count += 1
                log.info(f"Missing [{lang}]: {video.name}")
                if search_subtitle(video, lang):
                    downloaded_count += 1
                    log.info(f"  Downloaded: {video.name}")

    log.info(f"=== Scan complete: {missing_count} missing, {downloaded_count} downloaded ===")

    # Write status file for bot to read
    status = {
        'last_scan': datetime.now().isoformat(),
        'total_videos': len(videos),
        'missing_count': missing_count,
        'downloaded_count': downloaded_count
    }
    with open('/config/status.json', 'w') as f:
        json.dump(status, f, indent=2)


def main():
    # Initial scan
    scan_media()

    # Periodic scan
    log.info(f"Sleeping {SCAN_INTERVAL}s until next scan...")
    while True:
        time.sleep(SCAN_INTERVAL)
        scan_media()


if __name__ == '__main__':
    main()
