#!/usr/bin/env python3
"""
File Watchdog: monitors media folder for new video files.
When new file appears, trigger SubGen to scan.
"""
import os
import sys
import time
import logging
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s'
)
log = logging.getLogger('watchdog')

MEDIA_PATH = os.environ.get('MEDIA_PATH', '/volume1/data/media')
VIDEO_EXTS = {'.mkv', '.mp4', '.avi', '.mov', '.wmv', '.flv', '.webm'}


class VideoHandler(FileSystemEventHandler):
    def on_created(self, event):
        if event.is_directory:
            return
        path = event.src_path
        ext = os.path.splitext(path)[1].lower()
        if ext in VIDEO_EXTS:
            log.info(f"New video detected: {path}")
            # Wait for file to finish downloading (qBittorrent temp files)
            self.wait_for_complete(path)

    def wait_for_complete(self, path, timeout=300):
        """Wait until file size stops changing (download complete)."""
        log.info(f"Waiting for {path} to finish downloading...")
        last_size = -1
        stable_count = 0
        start = time.time()

        while time.time() - start < timeout:
            try:
                current_size = os.path.getsize(path)
                if current_size == last_size:
                    stable_count += 1
                    if stable_count >= 3:  # 3 checks = stable
                        log.info(f"File complete: {path} ({current_size} bytes)")
                        self.trigger_subgen()
                        return
                else:
                    stable_count = 0
                    last_size = current_size
            except OSError:
                pass
            time.sleep(5)

        log.warning(f"File size still changing after {timeout}s, triggering anyway")
        self.trigger_subgen()

    def trigger_subgen(self):
        """Trigger SubGen to re-scan."""
        # Use Docker API or just exec into subgen container
        import subprocess
        try:
            subprocess.run(['docker', 'exec', 'media-subgen', 'python', '-c',
                            'import sys; sys.path.insert(0, \"/app\"); from subgen_runner import scan_media; scan_media()'],
                           check=True, timeout=10)
            log.info("SubGen scan triggered")
        except Exception as e:
            log.error(f"Failed to trigger SubGen: {e}")


def main():
    if not os.path.exists(MEDIA_PATH):
        log.error(f"Media path {MEDIA_PATH} does not exist")
        return

    event_handler = VideoHandler()
    observer = Observer()
    observer.schedule(event_handler, MEDIA_PATH, recursive=True)
    observer.start()

    log.info(f"Watchdog started, monitoring {MEDIA_PATH}")
    try:
        while True:
            time.sleep(60)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()


if __name__ == '__main__':
    main()
