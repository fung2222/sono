# NAS Media Stack Deployment Guide

## 概述

Telegram Bot + SubGen + Watchdog for UGREEN DXP4800+ NAS (Docker).

**功能**:
- 🤖 Telegram bot: `/status` `/missing` `/searchall` `/qbitt` `/jellyfin`
- 🔍 SubGen: 自動掃描 media folder, 搵/下載字幕
- 👀 Watchdog: 監新 file, 自動 trigger SubGen

## Prerequisites

- [ ] UGREEN DXP4800+ NAS with Docker
- [ ] Container Manager (UGREEN's Docker UI)
- [ ] qBittorrent + Jellyfin + TMM already set up
- [ ] Telegram account
- [ ] Media folder accessible to Docker (e.g. `/volume1/data/media`)

## Step 1: Create Telegram Bot

1. Open Telegram, message `@BotFather`
2. Send `/newbot`
3. Follow prompts: name + username
4. Copy the **bot token** (e.g. `123456:ABC-DEF...`)

## Step 2: Get Your Telegram chat_id

1. Message `@userinfobot` on Telegram
2. It will reply with your chat_id (e.g. `123456789`)

## Step 3: Get qBittorrent Credentials

1. Open qBittorrent WebUI
2. Note URL (e.g. `http://192.168.1.50:8080`)
3. Use your existing username/password

## Step 4: Get Jellyfin API Key

1. Open Jellyfin Admin Dashboard
2. Go to Administration → API Keys
3. Click "+" to create new key
4. Copy the key

## Step 5: Setup NAS Folder Structure

SSH into NAS or use File Manager:

```bash
mkdir -p /volume1/docker/media-bot
mkdir -p /volume1/docker/media-bot/scripts
cd /volume1/docker/media-bot
```

## Step 6: Copy Files

Copy these files from `/opt/data/scripts/nas-media-stack/`:

```
/volume1/docker/media-bot/
├── docker-compose.yml
├── .env
└── scripts/
    ├── subgen_runner.py
    ├── bot.py
    └── watchdog.py
```

## Step 7: Edit `.env`

```bash
nano .env
```

Fill in your actual values:
- `NAS_IP`
- `QBITT_URL`, `QBITT_USER`, `QBITT_PASS`
- `JELLYFIN_URL`, `JELLYFIN_API_KEY`
- `TELEGRAM_BOT_TOKEN`
- `ALLOWED_CHAT_IDS=your_chat_id`

## Step 8: Start Services

```bash
cd /volume1/docker/media-bot
docker compose up -d
```

Check logs:
```bash
docker compose logs -f subgen
docker compose logs -f bot
docker compose logs -f watchdog
```

## Step 9: Test

Open Telegram, message your bot, send `/start`.

You should see the welcome message with command list.

Try:
- `/status` - SubGen status
- `/searchall` - Trigger subtitle search
- `/qbitt` - qBittorrent status
- `/jellyfin` - Jellyfin status

## Maintenance

### Update Bot Token

```bash
cd /volume1/docker/media-bot
nano .env  # edit TELEGRAM_BOT_TOKEN
docker compose restart bot
```

### Add More Allowed chat_ids

Edit `.env`:
```
ALLOWED_CHAT_IDS=123456789,987654321
docker compose restart bot
```

### View Logs

```bash
docker compose logs -f --tail=100
```

### Backup Config

```bash
cp -r /volume1/docker/media-bot /volume1/backup/media-bot-$(date +%Y%m%d)
```

## Troubleshooting

### Bot not responding

1. Check logs: `docker compose logs bot`
2. Verify token: `docker exec media-bot env | grep TELEGRAM`
3. Restart: `docker compose restart bot`

### SubGen not finding subtitles

1. Check media path is correct in `.env`
2. Check Docker can access: `docker exec media-subgen ls /media`
3. Check OpenSubtitles API key (if required)

### Watchdog not detecting

1. Check media path permissions
2. Test: `docker exec media-watchdog ls /media`
3. Check file is video extension (.mkv, .mp4, etc.)

## Security

- ⚠️ NEVER commit `.env` to git
- ⚠️ `chat_id` whitelist limits bot access
- ⚠️ Rotate Telegram token if compromised
- ⚠️ Use Jellyfin API key (not admin password)
